

  <nav>
             <ul>
              <li><a href="includes/contenido4.php" class="nueva-ventana"><span>Nueva Venta</span></a></li>
              <li><a href="includes/contenido2.php" class="cerrar-ventana"><span>Cerrar  Venta</span></a></li>
              <li><a href="includes/contenido3.php" class="devoluciones"><span>Cambios, devoluciones y pedidos</span></a></li>
              <li><a href="includes/contenido.php" class="pagos"><span>Pagos y apartados</span></a></li>
             </ul>  
         </nav>